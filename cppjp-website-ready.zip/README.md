# Site Web - Cours Privés Le Pédagogue Jean Piaget

## Description

Site web professionnel pour l'école CPPJP (Cours Privés Le Pédagogue Jean Piaget) située à Yeumbeul Asecna, Dakar, Sénégal.

## Caractéristiques

### Design et Interface
- **Design moderne et professionnel** avec palette de couleurs basée sur le logo de l'école
- **Responsive design** adapté aux ordinateurs, tablettes et mobiles
- **Navigation intuitive** avec menu fixe et liens d'ancrage
- **Animations fluides** et effets de transition
- **Accessibilité optimisée** avec support clavier et lecteurs d'écran

### Sections du Site

1. **Page d'accueil (Hero)**
   - Présentation de l'école avec logo
   - Message d'accueil et boutons d'action

2. **À propos**
   - Mission et valeurs de l'école
   - Statistiques clés (4 niveaux, 15+ années d'expérience, 100% réussite)

3. **Programmes d'études**
   - **Préscolaire** (3-5 ans) : Développement global de l'enfant
   - **Élémentaire** (7-12 ans) : Compétences de base en 3 étapes
   - **Moyen** (12-16 ans) : Préparation au BFEM
   - **Secondaire** (16-19 ans) : 3 filières (L, G, S) pour le baccalauréat

4. **Admissions**
   - Processus d'inscription en 4 étapes
   - Formulaire de demande d'information

5. **Contact**
   - Informations complètes (adresse, téléphones, email, horaires)
   - Carte de localisation

6. **Footer**
   - Liens rapides vers les programmes
   - Informations de contact
   - Réseaux sociaux
   - Copyright

### Fonctionnalités Techniques

- **HTML5 sémantique** pour un bon référencement
- **CSS3 moderne** avec variables CSS et Flexbox/Grid
- **JavaScript interactif** pour la navigation et les animations
- **Formulaire de contact** avec validation en temps réel
- **Optimisation SEO** avec meta tags appropriés
- **Performance optimisée** avec lazy loading des images

### Palette de Couleurs

- **Vert principal** : #2D5A4A (couleur dominante du logo)
- **Rouge accent** : #C41E3A (couleur des étoiles)
- **Doré/Orange** : #F4A261 (couleur de la flamme)
- **Blanc** : #FFFFFF
- **Gris foncé** : #2C3E50

## Structure des Fichiers

```
cppjp-website/
├── index.html          # Page principale
├── styles.css          # Feuille de style
├── script.js           # JavaScript interactif
├── README.md           # Documentation
└── assets/
    └── images/
        └── logo.jpeg    # Logo de l'école
```

## Informations de Contact de l'École

- **Nom** : Cours Privés Le Pédagogue Jean Piaget
- **Adresse** : Yeumbeul Asecna, près du lycée de Yeumbeul, Dakar, Sénégal
- **Téléphones** : 775 35 25 91 - 338 01 73 46
- **Email** : 2024cppjp@gmail.com
- **Horaires** : 
  - Lundi - Vendredi : 7h30 - 17h00
  - Samedi : 8h00 - 12h00

## Utilisation

1. Ouvrez le fichier `index.html` dans un navigateur web
2. Le site est entièrement fonctionnel en local
3. Pour le déployer en ligne, uploadez tous les fichiers sur un serveur web

## Compatibilité

- **Navigateurs** : Chrome, Firefox, Safari, Edge (versions récentes)
- **Appareils** : Ordinateurs, tablettes, smartphones
- **Résolutions** : Optimisé pour toutes les tailles d'écran

## Maintenance

Le site est conçu pour être facilement maintenable :
- Contenu modifiable dans le fichier HTML
- Styles centralisés dans le fichier CSS
- JavaScript modulaire et commenté

---

**Développé avec excellence pour l'école CPPJP**

